window.handleClick();

function handleClick() {
	var submit = document.getElementById('submit');
	submit.addEventListener('click', handleItem);
};

function handleItem(e) {
	//remove default action
	e.preventDefault;

	var listItem = document.getElementById('todolist');
	var list = document.getElementById('list');

	var listItemValue = listItem.value;
	var itemlist = [];
	itemlist.push(listItemValue);

	if (listItemValue == '' || listItemValue == null){
		alert('Please Enter a value');
		return false;
	}
	else {
		for (var i = 0; i < itemlist.length; i++){
			list.innerHTML = '<li>' + itemlist[i] + '<li>';

		}
	}
};


  